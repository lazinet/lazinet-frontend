
import React, { useState, useRef, useEffect } from 'react';
import { DEFAULT_DATA } from './constants';
import { BrochureData, PageSize, PAGE_SCALES } from './types';
import { 
  Download, 
  Image as ImageIcon, 
  FileText, 
  Share2, 
  Calendar, 
  Plus, 
  Trash2, 
  Printer,
  Upload,
  Globe,
  ShieldCheck,
  Phone,
  Mail,
  MapPin,
  Settings
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// --- Utility Components ---

const EditableContent: React.FC<{
  value: string;
  onChange: (val: string) => void;
  className?: string;
  multiline?: boolean;
}> = ({ value, onChange, className = "", multiline = false }) => {
  const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
    onChange(e.currentTarget.innerHTML);
  };

  return (
    <div
      contentEditable
      suppressContentEditableWarning
      className={`outline-none transition-colors focus:bg-red-50 focus:ring-1 focus:ring-red-300 rounded px-1 -mx-1 ${className}`}
      onBlur={handleInput}
      dangerouslySetInnerHTML={{ __html: value }}
    />
  );
};

// --- Main App Component ---

export default function App() {
  const [data, setData] = useState<BrochureData>(DEFAULT_DATA);
  const [selectedSize, setSelectedSize] = useState<PageSize>('A4');
  const [isExporting, setIsExporting] = useState(false);
  const brochureRef = useRef<HTMLDivElement>(null);
  const [mainIconUrl, setMainIconUrl] = useState<string>('');

  // Handle Logo Uploads
  const handleLogoUpload = (type: 'viettel' | 'partner' | 'mainIcon') => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (type === 'viettel') setData(prev => ({ ...prev, viettelLogo: result }));
        if (type === 'partner') setData(prev => ({ ...prev, partnerLogo: result }));
        if (type === 'mainIcon') {
          setData(prev => ({ ...prev, mainIcon: result }));
          setMainIconUrl(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSectionChange = (index: number, field: 'title' | 'content', val: string) => {
    const newSections = [...data.sections];
    newSections[index] = { ...newSections[index], [field]: val };
    setData(prev => ({ ...prev, sections: newSections }));
  };

  const exportAsImage = async () => {
    if (!brochureRef.current) return;
    setIsExporting(true);
    // Allow React to render state change if any
    await new Promise(r => setTimeout(r, 100));

    const canvas = await html2canvas(brochureRef.current, {
      scale: 3, // High quality
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });
    
    const link = document.createElement('a');
    link.download = `Viettel-Software-Brochure-${selectedSize}.png`;
    link.href = canvas.toDataURL('image/png', 1.0);
    link.click();
    setIsExporting(false);
  };

  const exportAsPdf = async () => {
    if (!brochureRef.current) return;
    setIsExporting(true);
    await new Promise(r => setTimeout(r, 100));

    const canvas = await html2canvas(brochureRef.current, {
      scale: 2,
      useCORS: true,
      backgroundColor: '#ffffff'
    });

    const scale = PAGE_SCALES[selectedSize];
    const width = 210 * scale;
    const height = 297 * scale;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: selectedSize.toLowerCase() as any
    });

    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, width, height, undefined, 'FAST');
    pdf.save(`Viettel-Software-Brochure-${selectedSize}.pdf`);
    setIsExporting(false);
  };

  const exportAsWord = () => {
    // Better Word format using MHTML or simple standard HTML blob
    const html = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><meta charset='utf-8'><title>Brochure</title></head>
      <body>
        <h1>${data.headerTitle}</h1>
        <hr/>
        ${data.sections.map(s => `
          <h2>${s.title}</h2>
          <div>${s.content}</div>
        `).join('')}
        <hr/>
        <h3>${data.hanoiContact.title}</h3>
        <p>${data.hanoiContact.address}</p>
        <p>Tel: ${data.hanoiContact.phone}</p>
        <p>Email: ${data.hanoiContact.email}</p>
        <hr/>
        <h3>${data.hcmContact.title}</h3>
        <p>${data.hcmContact.address}</p>
        <p>Tel: ${data.hcmContact.representative} ${data.hcmContact.phone}</p>
        <p>Email: ${data.hcmContact.email}</p>
        <hr/>
        <p>Website: ${data.website}</p>
        <p>Tax Code: ${data.taxCode}</p>
      </body>
      </html>
    `;
    const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'Viettel-Software-Brochure.doc';
    link.click();
  };

  return (
    <div className="min-h-screen pb-20 flex flex-col items-center bg-gray-50">
      {/* Header / Nav */}
      <header className="w-full bg-white shadow-sm py-4 px-6 flex justify-between items-center mb-8 sticky top-0 z-50 no-print">
        <div className="flex items-center gap-3">
          <div className="bg-red-600 p-2 rounded-lg">
            <Settings className="text-white w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-gray-800">
            VTIT Brochure Builder
          </h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            {(['A0', 'A1', 'A2', 'A3', 'A4', 'A5'] as PageSize[]).map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                  selectedSize === size 
                    ? 'bg-white text-red-600 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-7xl flex flex-col lg:flex-row gap-8 px-4 items-start justify-center">
        
        {/* Editor Sidebar */}
        <div className="w-full lg:w-80 flex flex-col gap-6 no-print">
          <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-red-500" />
              Hình ảnh & Logo
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-gray-500 block mb-2 uppercase tracking-wider">Logo Viettel</label>
                <input type="file" onChange={handleLogoUpload('viettel')} className="block w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100 cursor-pointer" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 block mb-2 uppercase tracking-wider">Logo Đối Tác</label>
                <input type="file" onChange={handleLogoUpload('partner')} className="block w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100 cursor-pointer" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 block mb-2 uppercase tracking-wider">Icon Chính (logo-phung.png)</label>
                <input type="file" onChange={handleLogoUpload('mainIcon')} className="block w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer" />
              </div>
            </div>
          </section>

          <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4 text-red-500" />
              Thêm nội dung
            </h3>
            <button 
              onClick={() => setData(prev => ({...prev, sections: [...prev.sections, { title: "Mục Mới", content: "Nội dung mục mới..." }]}))}
              className="w-full py-2 px-4 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2 text-sm font-medium border border-dashed border-gray-300"
            >
              <Plus className="w-4 h-4" /> Thêm Section
            </button>
          </section>

          <section className="bg-red-600 p-6 rounded-2xl shadow-lg shadow-red-100 text-white">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Download className="w-4 h-4" />
              Xuất tài liệu
            </h3>
            <div className="grid grid-cols-1 gap-3">
              <button onClick={exportAsImage} className="w-full bg-white/10 hover:bg-white/20 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm transition-all backdrop-blur-md">
                <ImageIcon className="w-4 h-4" /> Xuất Ảnh ({selectedSize})
              </button>
              <button onClick={exportAsPdf} className="w-full bg-white text-red-600 hover:bg-red-50 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 text-sm transition-all">
                <FileText className="w-4 h-4" /> Xuất PDF ({selectedSize})
              </button>
              <button onClick={exportAsWord} className="w-full bg-white/10 hover:bg-white/20 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm transition-all">
                <FileText className="w-4 h-4" /> Xuất Word
              </button>
              <button className="w-full bg-white/10 hover:bg-white/20 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm transition-all opacity-50 cursor-not-allowed">
                <Printer className="w-4 h-4" /> In Trực Tiếp
              </button>
            </div>
          </section>
        </div>

        {/* Brochure Preview Area */}
        <div className="flex-1 flex justify-center w-full overflow-auto hide-scrollbar py-4 px-4 bg-gray-200 rounded-3xl shadow-inner border border-gray-300">
          <div 
            ref={brochureRef}
            id="brochure-card"
            className="bg-white shadow-2xl relative flex flex-col box-border overflow-hidden"
            style={{ 
              width: '210mm', 
              minHeight: '297mm',
              padding: '15mm',
              transformOrigin: 'top center',
              // Scaling for display purpose only if needed, usually we just keep it A4 fixed size in the browser
            }}
          >
            {/* Corner Decorations */}
            <div className="absolute top-4 left-4 w-12 h-12 border-t-4 border-l-4 border-red-600 opacity-20"></div>
            <div className="absolute top-4 right-4 w-12 h-12 border-t-4 border-r-4 border-purple-600 opacity-20"></div>
            <div className="absolute bottom-4 left-4 w-12 h-12 border-b-4 border-l-4 border-red-600 opacity-20"></div>
            <div className="absolute bottom-4 right-4 w-12 h-12 border-b-4 border-r-4 border-purple-600 opacity-20"></div>

            {/* Gradient Top/Bottom Borders */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-600 via-purple-600 to-red-600"></div>
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-600 via-purple-600 to-red-600"></div>

            {/* Header */}
            <header className="flex items-center justify-between mb-8 gap-6 relative z-10">
              <img src={data.viettelLogo} alt="Viettel" className="h-12 object-contain" />
              <div className="flex-1">
                <EditableContent 
                  value={data.headerTitle} 
                  onChange={(val) => setData(prev => ({...prev, headerTitle: val}))}
                  className="text-center font-bold text-2xl tracking-tighter text-gray-900 border-b border-gray-200 pb-1"
                />
              </div>
              <img src={data.partnerLogo} alt="Partner" className="h-12 w-auto max-w-[150px] object-contain opacity-80" />
            </header>

            {/* Main Content Sections */}
            <div className="flex-1 space-y-6 relative z-10">
              {data.sections.map((section, idx) => (
                <div key={idx} className="group relative">
                  <div className="flex items-center gap-3 mb-2 pb-1 border-b border-gray-800">
                    {data.mainIcon ? (
                      <img src={data.mainIcon} alt="Icon" className="w-6 h-6 object-contain" />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-red-600" />
                    )}
                    <EditableContent 
                      value={section.title}
                      onChange={(val) => handleSectionChange(idx, 'title', val)}
                      className="font-bold text-lg text-red-600 tracking-tight flex-1 uppercase"
                    />
                    <button 
                      onClick={() => setData(prev => ({...prev, sections: prev.sections.filter((_, i) => i !== idx)}))}
                      className="no-print opacity-0 group-hover:opacity-100 transition-opacity text-red-300 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <EditableContent 
                    value={section.content}
                    onChange={(val) => handleSectionChange(idx, 'content', val)}
                    className="text-gray-700 leading-relaxed text-[13px]"
                    multiline
                  />
                </div>
              ))}
            </div>

            {/* Footer / Contact */}
            <footer className="mt-8 pt-6 border-t border-gray-100 relative z-10">
              <div className="text-center mb-6">
                <EditableContent 
                   value={data.companyFullName}
                   onChange={(val) => setData(prev => ({...prev, companyFullName: val}))}
                   className="font-bold text-sm mb-1 uppercase text-gray-800"
                />
                <div className="flex items-center justify-center gap-6 text-[11px] text-gray-500">
                  <span className="flex items-center gap-1">
                    <Globe className="w-3 h-3 text-red-500" />
                    <EditableContent value={data.website} onChange={(val) => setData(prev => ({...prev, website: val}))} />
                  </span>
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-red-500" />
                    MST: <EditableContent value={data.taxCode} onChange={(val) => setData(prev => ({...prev, taxCode: val}))} />
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Hanoi Office */}
                <div className="bg-gray-50 p-4 rounded-xl border-l-4 border-red-600">
                   <EditableContent 
                    value={data.hanoiContact.title}
                    onChange={(val) => setData(prev => ({...prev, hanoiContact: {...prev.hanoiContact, title: val}}))}
                    className="font-bold text-red-600 text-xs mb-2 tracking-wide"
                  />
                  <div className="space-y-1 text-[11px] text-gray-600">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-3 h-3 mt-0.5 text-gray-400 shrink-0" />
                      <EditableContent value={data.hanoiContact.address} onChange={(val) => setData(prev => ({...prev, hanoiContact: {...prev.hanoiContact, address: val}}))} />
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3 h-3 text-gray-400 shrink-0" />
                      <EditableContent value={data.hanoiContact.phone} onChange={(val) => setData(prev => ({...prev, hanoiContact: {...prev.hanoiContact, phone: val}}))} />
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-3 h-3 text-gray-400 shrink-0" />
                      <EditableContent value={data.hanoiContact.email} onChange={(val) => setData(prev => ({...prev, hanoiContact: {...prev.hanoiContact, email: val}}))} />
                    </div>
                  </div>
                </div>

                {/* HCM Office */}
                <div className="bg-gray-50 p-4 rounded-xl border-l-4 border-red-600">
                  <EditableContent 
                    value={data.hcmContact.title}
                    onChange={(val) => setData(prev => ({...prev, hcmContact: {...prev.hcmContact, title: val}}))}
                    className="font-bold text-red-600 text-xs mb-2 tracking-wide"
                  />
                  <div className="space-y-1 text-[11px] text-gray-600">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-3 h-3 mt-0.5 text-gray-400 shrink-0" />
                      <EditableContent value={data.hcmContact.address} onChange={(val) => setData(prev => ({...prev, hcmContact: {...prev.hcmContact, address: val}}))} />
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3 h-3 text-gray-400 shrink-0" />
                      <div className="flex items-center gap-2">
                        <EditableContent 
                          value={`<strong>${data.hcmContact.representative}</strong> ${data.hcmContact.phone}`} 
                          onChange={(val) => {
                            // Simple split logic or manual parsing if needed
                            setData(prev => ({...prev, hcmContact: {...prev.hcmContact, phone: val}}));
                          }} 
                        />
                        {data.hcmContact.socials && (
                          <div className="flex items-center gap-1 no-print">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Icon_of_Zalo.svg/50px-Icon_of_Zalo.svg.png" className="h-3 w-3" alt="Zalo" />
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Viber_logo.svg/2560px-Viber_logo.svg.png" className="h-3 w-3" alt="Viber" />
                            <img src="https://static.whatsapp.net/rsrc.php/yZ/r/JvsnINJ2CZv.svg" className="h-3 w-3" alt="WA" />
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-3 h-3 text-gray-400 shrink-0" />
                      <EditableContent value={data.hcmContact.email} onChange={(val) => setData(prev => ({...prev, hcmContact: {...prev.hcmContact, email: val}}))} />
                    </div>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        </div>
      </main>

      {/* Floating Action Buttons for Mobile */}
      <div className="lg:hidden fixed bottom-6 right-6 flex flex-col gap-3 no-print">
        <button onClick={exportAsPdf} className="bg-red-600 text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform">
          <Download className="w-6 h-6" />
        </button>
      </div>

      {/* Simple Instruction for Users */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t border-gray-100 py-2 px-6 flex justify-center gap-8 no-print text-[10px] font-medium text-gray-400 uppercase tracking-widest">
        <span>Click directly on text to edit</span>
        <span>Drag & drop images to replace</span>
        <span>Choose paper size for high-res exports</span>
      </div>
    </div>
  );
}
