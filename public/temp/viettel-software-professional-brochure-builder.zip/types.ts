
export interface ContactInfo {
  title: string;
  address: string;
  phone: string;
  email: string;
  representative?: string;
  socials?: {
    zalo?: string;
    viber?: string;
    whatsapp?: string;
  };
}

export interface BrochureSection {
  title: string;
  content: string; // HTML allowed for lists
}

export interface BrochureData {
  headerTitle: string;
  viettelLogo: string;
  partnerLogo: string;
  mainIcon: string; // The logo-phung.png equivalent
  sections: BrochureSection[];
  hanoiContact: ContactInfo;
  hcmContact: ContactInfo;
  companyFullName: string;
  website: string;
  taxCode: string;
}

export type PageSize = 'A0' | 'A1' | 'A2' | 'A3' | 'A4' | 'A5';

export const PAGE_SCALES: Record<PageSize, number> = {
  'A0': 4,
  'A1': 2.828,
  'A2': 2,
  'A3': 1.414,
  'A4': 1,
  'A5': 0.707,
};
