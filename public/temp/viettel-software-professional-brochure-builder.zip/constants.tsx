
import { BrochureData } from './types';

export const DEFAULT_DATA: BrochureData = {
  headerTitle: "GIỚI THIỆU TÓM TẮT",
  viettelLogo: "https://hr1tech.com/htdocs/images/owners/hr1tech/logo/202311/logo-jfif.png",
  partnerLogo: "https://picsum.photos/seed/partner/200/80",
  mainIcon: "", // Will be loaded by user or default
  companyFullName: "CÔNG TY TNHH MTV ĐẦU TƯ CÔNG NGHỆ VIETTEL (VTIT) - VIETTEL SOFTWARE",
  website: "viettelsoftware.com",
  taxCode: "2801045888",
  sections: [
    {
      title: "VỀ VIETTEL SOFTWARE",
      content: "<strong>Viettel Software</strong> (VTIT), thành viên của <strong>Tập đoàn Viettel</strong>, là nhà cung cấp hàng đầu các dịch vụ gia công phần mềm và giải pháp CNTT tiên tiến. Với hơn <strong>1.500</strong> chuyên gia cùng đội ngũ không ngừng mở rộng, chúng tôi cam kết thúc đẩy chuyển đổi số tại Việt Nam và vươn tầm công nghệ toàn cầu."
    },
    {
      title: "LÝ DO HỢP TÁC VỚI VIETTEL SOFTWARE",
      content: "<ul><li><strong>Tùy biến chuyên sâu</strong>: Giải quyết triệt để vấn đề nhức nhối, thích ứng cao độ mô hình kinh doanh.</li><li><strong>Tiêu chuẩn toàn cầu</strong>: Quy trình tối ưu, đạt chứng nhận quốc tế <strong>CMMI5</strong>, <strong>ISO-27001</strong> và <strong>ISO-9001</strong>.</li><li><strong>Công nghệ vượt trội</strong>: Dẫn đầu về <strong>AI</strong>, <strong>IoT</strong>, <strong>Blockchain</strong> và <strong>Big Data</strong>.</li></ul>"
    },
    {
      title: "DỊCH VỤ CỦA VIETTEL SOFTWARE",
      content: "<ul><li><strong>Tư vấn giải pháp</strong>: Xây dựng chiến lược, thiết kế giải pháp toàn trình.</li><li><strong>Gia công phần mềm</strong>: Chuyển đổi, nâng cấp, phát triển mới phần mềm tùy chỉnh.</li><li><strong>Phái cử chuyên gia</strong>: Nhân sự năng lực cao, giám sát hiệu quả.</li></ul>"
    },
    {
      title: "KINH NGHIỆM CỦA VIETTEL SOFTWARE",
      content: "<ul><li><strong>Viễn thông & Công nghệ mới</strong>: OSS, BSS, Big Data, AI/ OCR/ LLM.</li><li><strong>Quản trị doanh nghiệp</strong>: ERP/ EAS, CRM, Super App.</li><li><strong>Tài chính số</strong>: Ví điện tử, Ngân hàng số.</li></ul>"
    }
  ],
  hanoiContact: {
    title: "TRỤ SỞ CHÍNH",
    address: "36A Dịch Vọng Hậu, Cầu Giấy, Hà Nội",
    phone: "+84-988889446",
    email: "contact@viettelsoftware.com"
  },
  hcmContact: {
    title: "VĂN PHÒNG MIỀN NAM",
    address: "Tòa nhà Viettel, 285 CMT8, Hòa Hưng, HCM",
    phone: "+84-983667248",
    email: "phunghm@viettelsoftware.com",
    representative: "Mr. Phụng",
    socials: {
      zalo: "84983667248",
      viber: "84983667248",
      whatsapp: "84983667248"
    }
  }
};
