
import React, { useState, useRef, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Download, Plus, Trash2, Globe, ShieldCheck, 
  Phone, Mail, MapPin, Settings, FileDown, FileImage, 
  Layers, Info, AlertCircle
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// --- Default Assets (Base64) ---
const LOGO_VIETTEL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABACAYAAABv9X9cAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJVSURBVHgB7Zu9SgNBFIWvEBNBRAtB7C20shS0shS01D76EPY+hD6EFFr6EPoYUrjWUnvBRBAsLKKI6I8S5m6y6+6sm83urvOBy87O7p6Z79yZ3Z0LCAQCgcBfIB6PJzY2NqY8Hg+v+C/xeDxp00f9iYmJpMvlou+E91/8uOnh/pT92eN6vX6P/X4k69Tf593dXevk5MS6vb2N7Ozs2M8XFxfW4eGhzW9ublpPT0/W6emp9fT0ZPOfn59bZ2dnNn99fW396/m6X8t0e3v76f39vU2f9ScmJpJ6vR5vNpuO40X93eN67rXoA+v9/f32Nf1H+79u+tXW7u6u9fDwwH4Y9Gv61Y76r83+6fT01Lo/vS96X9X/8fGx9vX6l+X9X7X/+vXNzs7W/u9u7D/N/v7T6f/j6X/P13P/GfV/Yf9S0v+OqP8L+5eS/ndE/V/Yv5T0vyPq/8L+paT/HVH/F/YvJf3viPq/sH8p6X9H1P+F/UtJ/zui/i/sX0r63xH1f2H/UtL/jqj/C/uXkv53RP1f2L+U9L8j6v/C/qWk/x1R/xf2LyX974j6v7B/Kel/R9T/hf1LSf87ov4v7F9K+t8R9X9h/1LS/46o/wv7l5L+d0T9X9i/lPS/I+r/wv6lpP8dUf8X9i8l/e+I+r+wfynpf0fU/4X9S0n/O6L+L+xfSvof8v2+p/u/6/4v9X+o/yv1X9U/v+O6X8v9f2S6vLz8Yrvd9uOfB+N677XYf0f9YfNf/Oixv8vlfvT9X6X/P9D/mO73vO7Xcv+fWP+vY8965N7X87rX7fL+9UvXqf993/7Uf08gEAgEAoFvIgS+AInRj9Hh6Y/pAAAAAElFTkSuQmCC";
const ICON_PHUNG_DEFAULT = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4V8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABJUlEQVR4nO2YwYqDMBRFD8V+iP//ix8oIoiIuOnAnUnTNDSppZ2XBy4mXOY1D48XoiiKovxH0vYfAOB7zK+07fXG878n7RMAAOd8V7Yf51o553zV9vOf78A+AYAxRtK217XvI2lbpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpHfXh6T996RtX78z7RP3Cdf1N7N/6Cdt0zb6S9u6Tf99Jm2Tf+vYPnW978A+8Y20Te9L29Tf92O/NLY/7fK2+8A+AYAxRtK217XvI2lbpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpD6R+kTqE6lPpHfXh6T996RtX78z7RP3Cdf1N7N/6Cdt0zb6S9u6Tf99Jm2Tf+vYPnW978A+AW6v6pW2v/79u/Y6SdsX70fLwwAAAABJRU5ErkJggg==";

type PageSize = 'A0' | 'A1' | 'A2' | 'A3' | 'A4' | 'A5';

const PAGE_SCALES: Record<PageSize, number> = {
  'A0': 4, 'A1': 2.828, 'A2': 2, 'A3': 1.414, 'A4': 1, 'A5': 0.707
};

const PAGE_DIMENSIONS: Record<PageSize, { w: number, h: number }> = {
  'A0': { w: 841, h: 1189 },
  'A1': { w: 594, h: 841 },
  'A2': { w: 420, h: 594 },
  'A3': { w: 297, h: 420 },
  'A4': { w: 210, h: 297 },
  'A5': { w: 148, h: 210 }
};

const App = () => {
  const [data, setData] = useState({
    headerTitle: "GIỚI THIỆU TÓM TẮT",
    companyFullName: "CÔNG TY TNHH MTV ĐẦU TƯ CÔNG NGHỆ VIETTEL (VTIT) - VIETTEL SOFTWARE",
    website: "viettelsoftware.com",
    taxCode: "2801045888",
    sections: [
      { title: "VỀ VIETTEL SOFTWARE", content: "Viettel Software (VTIT), thành viên của Tập đoàn Viettel, là nhà cung cấp hàng đầu các dịch vụ gia công phần mềm và giải pháp CNTT tiên tiến. Với hơn 1.500 chuyên gia, chúng tôi cam kết thúc đẩy chuyển đổi số tại Việt Nam và vươn tầm công nghệ toàn cầu." },
      { title: "LÝ DO HỢP TÁC", content: "<ul><li>Tùy biến chuyên sâu giải pháp doanh nghiệp.</li><li>Quy trình tối ưu CMMI5, ISO-27001, ISO-9001.</li><li>Công nghệ vượt trội AI, Big Data, Cloud.</li></ul>" },
      { title: "DỊCH VỤ CHÍNH", content: "<ul><li>Tư vấn chuyển đổi số toàn diện.</li><li>Phát triển phần mềm tùy chỉnh (Custom Software).</li><li>Phái cử chuyên gia công nghệ cao.</li></ul>" },
      { title: "KINH NGHIỆM", content: "Dẫn đầu trong các lĩnh vực Viễn thông (OSS/BSS), Tài chính số (Ví điện tử, Ngân hàng số) và Quản trị doanh nghiệp (ERP, CRM)." }
    ],
    hanoiContact: {
      title: "TRỤ SỞ HÀ NỘI",
      address: "36A Dịch Vọng Hậu, Cầu Giấy, Hà Nội",
      phone: "+84-988889446",
      email: "contact@viettelsoftware.com"
    },
    hcmContact: {
      title: "VĂN PHÒNG MIỀN NAM",
      address: "Tòa nhà Viettel, 285 CMT8, Hòa Hưng, HCM",
      phone: "+84-983667248",
      email: "phunghm@viettelsoftware.com",
      representative: "Mr. Phụng"
    }
  });

  const [selectedSize, setSelectedSize] = useState<PageSize>('A4');
  const [phungIcon, setPhungIcon] = useState(ICON_PHUNG_DEFAULT);
  const [isOverflow, setIsOverflow] = useState(false);
  const brochureRef = useRef<HTMLDivElement>(null);

  // Check for content overflow on A4
  useEffect(() => {
    if (brochureRef.current) {
      const height = brochureRef.current.scrollHeight;
      const a4HeightPx = 297 * (96 / 25.4); // Approx A4 height in pixels
      setIsOverflow(height > a4HeightPx + 50);
    }
  }, [data]);

  const updateSection = (idx: number, field: string, val: string) => {
    const next = [...data.sections];
    next[idx] = { ...next[idx], [field]: val };
    setData({ ...data, sections: next });
  };

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setPhungIcon(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const exportPDF = async () => {
    if (!brochureRef.current) return;
    const dim = PAGE_DIMENSIONS[selectedSize];
    const scale = PAGE_SCALES[selectedSize] * 2; // Increase DPI for better quality

    const canvas = await html2canvas(brochureRef.current, {
      scale: scale,
      useCORS: true,
      scrollX: 0,
      scrollY: -window.scrollY,
      windowHeight: brochureRef.current.scrollHeight, // Capture full height
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png', 1.0);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: selectedSize.toLowerCase() as any
    });

    // Calculate height to avoid cutting if content is longer than standard page
    const contentHeight = (canvas.height * dim.w) / canvas.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, dim.w, contentHeight);
    pdf.save(`VTIT_Brochure_${selectedSize}.pdf`);
  };

  const exportImage = async () => {
    if (!brochureRef.current) return;
    const canvas = await html2canvas(brochureRef.current, {
      scale: 4, // Ultra high res for images
      useCORS: true,
      windowHeight: brochureRef.current.scrollHeight
    });
    const link = document.createElement('a');
    link.download = `VTIT_Brochure_${selectedSize}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const exportWord = () => {
    const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head><meta charset='utf-8'><title>VTIT Brochure</title><style>
      body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; }
      .header { color: #ee0000; font-size: 24pt; font-weight: bold; text-align: center; margin-bottom: 20pt; }
      .company { font-weight: bold; text-align: center; font-size: 14pt; margin-bottom: 10pt; }
      .section-title { color: #ee0000; font-size: 16pt; font-weight: bold; border-bottom: 1px solid #000; margin-top: 20pt; }
      .contact-box { background: #f9f9f9; padding: 10pt; margin-top: 20pt; border-left: 5pt solid #ee0000; }
    </style></head><body>`;
    
    const content = `
      <div class="header">${data.headerTitle}</div>
      <div class="company">${data.companyFullName}</div>
      ${data.sections.map(s => `
        <div class="section-title">${s.title}</div>
        <div class="section-content">${s.content}</div>
      `).join('')}
      <div class="contact-box">
        <strong>${data.hanoiContact.title}</strong><br/>
        Địa chỉ: ${data.hanoiContact.address}<br/>
        SĐT: ${data.hanoiContact.phone}<br/>
        Email: ${data.hanoiContact.email}
      </div>
      <div class="contact-box">
        <strong>${data.hcmContact.title}</strong><br/>
        Địa chỉ: ${data.hcmContact.address}<br/>
        Đại diện: <strong>${data.hcmContact.representative}</strong> - SĐT: ${data.hcmContact.phone}<br/>
        Email: ${data.hcmContact.email}
      </div>
      <p style="text-align: center; color: #888;">Website: ${data.website} | MST: ${data.taxCode}</p>
    </body></html>`;

    const blob = new Blob(['\ufeff', header + content], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'VTIT_Brochure.doc';
    link.click();
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-hidden">
      
      {/* SIDEBAR - NO PRINT */}
      <aside className="no-print w-full lg:w-96 bg-slate-900 text-white p-6 shrink-0 flex flex-col gap-6 shadow-2xl z-20 h-screen overflow-y-auto">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-5">
          <div className="bg-red-600 p-2.5 rounded-xl shadow-lg shadow-red-900/40">
            <Settings size={22} className="animate-spin-slow" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tight">Brochure Editor</h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Viettel Software Professional</p>
          </div>
        </div>

        <section className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
          <h3 className="text-xs font-black text-slate-400 uppercase mb-4 flex items-center gap-2">
            <Layers size={14} className="text-red-500" /> Kích thước bản xuất
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {(['A0','A1','A2','A3','A4','A5'] as PageSize[]).map(sz => (
              <button 
                key={sz}
                onClick={() => setSelectedSize(sz)}
                className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                  selectedSize === sz 
                    ? 'bg-red-600 border-red-500 text-white shadow-lg' 
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
          <div className="mt-3 flex items-start gap-2 text-[10px] text-slate-500 italic">
            <Info size={12} className="shrink-0 mt-0.5" />
            <span>Tự động tối ưu độ phân giải cho khổ {selectedSize}.</span>
          </div>
        </section>

        <section className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
          <h3 className="text-xs font-black text-slate-400 uppercase mb-4 flex items-center gap-2">
            <FileImage size={14} className="text-blue-500" /> Icon chính (logo-phung)
          </h3>
          <div className="flex items-center gap-4">
            <img src={phungIcon} className="w-12 h-12 bg-white rounded-lg p-1.5 shadow-inner object-contain" />
            <div className="flex-1">
              <input type="file" id="icon-phung" className="hidden" onChange={handleIconUpload} accept="image/*" />
              <label htmlFor="icon-phung" className="cursor-pointer block w-full text-center py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs font-bold border border-slate-600 transition-colors">
                Tải lên icon mới
              </label>
            </div>
          </div>
        </section>

        <section className="mt-auto space-y-3 pt-6 border-t border-slate-800">
          <button onClick={() => setData({...data, sections: [...data.sections, { title: "TIÊU ĐỀ MỚI", content: "Nội dung mục mới..." }]})} 
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 py-3 rounded-xl font-bold text-sm transition-all active:scale-95 shadow-lg shadow-blue-900/20">
            <Plus size={18} /> Thêm Mục Nội Dung
          </button>
          
          <div className="grid grid-cols-2 gap-3">
            <button onClick={exportPDF} className="flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 py-3 rounded-xl font-bold text-sm shadow-lg shadow-red-900/40 transition-all active:scale-95">
              <FileDown size={18} /> PDF
            </button>
            <button onClick={exportImage} className="flex items-center justify-center gap-2 bg-white text-slate-900 hover:bg-slate-100 py-3 rounded-xl font-bold text-sm shadow-lg transition-all active:scale-95">
              <FileImage size={18} /> Ảnh PNG
            </button>
          </div>
          <button onClick={exportWord} className="w-full flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 py-3 rounded-xl font-bold text-sm transition-all active:scale-95">
            <Download size={18} /> Xuất Word (.doc)
          </button>
        </section>

        {isOverflow && (
          <div className="bg-amber-900/30 border border-amber-800/50 p-3 rounded-xl flex items-start gap-3 text-amber-200">
            <AlertCircle size={20} className="shrink-0" />
            <div>
              <p className="text-[11px] font-bold">Nội dung vượt trang A4!</p>
              <p className="text-[10px] opacity-70">File PDF sẽ tự động kéo dài để lấy hết nội dung.</p>
            </div>
          </div>
        )}
      </aside>

      {/* BROCHURE DISPLAY */}
      <main className="flex-1 bg-slate-200 overflow-y-auto p-4 lg:p-10 flex flex-col items-center">
        
        <div 
          ref={brochureRef}
          className="brochure-page shadow-2xl transition-all"
        >
          {/* Decorative Elements */}
          <div className="absolute top-0 left-0 right-0 h-2.5 bg-gradient-to-r from-red-600 via-red-500 to-red-600" />
          <div className="absolute bottom-0 left-0 right-0 h-2.5 bg-gradient-to-r from-red-600 via-red-500 to-red-600" />
          <div className="absolute top-6 left-6 w-16 h-16 border-t-4 border-l-4 border-red-600/10" />
          <div className="absolute bottom-6 right-6 w-16 h-16 border-b-4 border-r-4 border-red-600/10" />

          {/* Header */}
          <header className="flex items-center justify-between mb-10 border-b-2 border-slate-100 pb-8 relative z-10">
            <img src={LOGO_VIETTEL} className="h-14 object-contain" alt="Viettel" />
            <div 
              className="flex-1 text-center mx-6 font-black text-3xl tracking-tighter text-slate-800 uppercase"
              contentEditable suppressContentEditableWarning
              onBlur={(e) => setData({...data, headerTitle: e.currentTarget.innerText})}
            >
              {data.headerTitle}
            </div>
            <div className="w-28 h-14 flex items-center justify-center border-2 border-dashed border-slate-200 rounded-xl text-[10px] text-slate-300 italic font-bold">
              Logo đối tác
            </div>
          </header>

          {/* Main Body */}
          <div className="flex-1 space-y-10 relative z-10">
            {data.sections.map((sec, i) => (
              <div key={i} className="group relative">
                <div className="flex items-center gap-4 mb-4">
                  <img src={phungIcon} className="w-8 h-8 object-contain shrink-0" alt="icon" />
                  <div 
                    className="flex-1 font-extrabold text-xl text-red-600 tracking-tight uppercase border-b border-red-50 pb-1"
                    contentEditable suppressContentEditableWarning
                    onBlur={(e) => updateSection(i, 'title', e.currentTarget.innerText)}
                  >
                    {sec.title}
                  </div>
                  <button onClick={() => setData({...data, sections: data.sections.filter((_, idx) => idx !== i)})}
                    className="no-print opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-red-500 transition-all">
                    <Trash2 size={18} />
                  </button>
                </div>
                <div 
                  className="text-slate-700 leading-relaxed text-[14px] pl-12 font-medium"
                  contentEditable suppressContentEditableWarning
                  onBlur={(e) => updateSection(i, 'content', e.currentTarget.innerHTML)}
                  dangerouslySetInnerHTML={{ __html: sec.content }}
                />
              </div>
            ))}
          </div>

          {/* Footer */}
          <footer className="mt-12 pt-10 border-t-2 border-slate-50 relative z-10">
            <div 
              className="text-center font-black text-[15px] text-slate-800 mb-8 uppercase tracking-widest leading-tight"
              contentEditable suppressContentEditableWarning
              onBlur={(e) => setData({...data, companyFullName: e.currentTarget.innerText})}
            >
              {data.companyFullName}
            </div>

            <div className="grid grid-cols-2 gap-8">
              {/* Hanoi Office */}
              <div className="bg-slate-50 p-5 rounded-2xl border-l-8 border-red-600 shadow-sm">
                <div 
                  className="font-black text-red-600 text-[11px] uppercase mb-3 tracking-widest"
                  contentEditable suppressContentEditableWarning
                  onBlur={(e) => setData({...data, hanoiContact: {...data.hanoiContact, title: e.currentTarget.innerText}})}
                >
                  {data.hanoiContact.title}
                </div>
                <div className="space-y-2 text-[12px] text-slate-600 font-semibold">
                  <div className="flex gap-3"><MapPin size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hanoiContact: {...data.hanoiContact, address: e.currentTarget.innerText}})}>{data.hanoiContact.address}</span>
                  </div>
                  <div className="flex gap-3"><Phone size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hanoiContact: {...data.hanoiContact, phone: e.currentTarget.innerText}})}>{data.hanoiContact.phone}</span>
                  </div>
                  <div className="flex gap-3"><Mail size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hanoiContact: {...data.hanoiContact, email: e.currentTarget.innerText}})}>{data.hanoiContact.email}</span>
                  </div>
                </div>
              </div>

              {/* HCM Office */}
              <div className="bg-slate-50 p-5 rounded-2xl border-l-8 border-red-600 shadow-sm">
                <div 
                  className="font-black text-red-600 text-[11px] uppercase mb-3 tracking-widest"
                  contentEditable suppressContentEditableWarning
                  onBlur={(e) => setData({...data, hcmContact: {...data.hcmContact, title: e.currentTarget.innerText}})}
                >
                  {data.hcmContact.title}
                </div>
                <div className="space-y-2 text-[12px] text-slate-600 font-semibold">
                  <div className="flex gap-3"><MapPin size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hcmContact: {...data.hcmContact, address: e.currentTarget.innerText}})}>{data.hcmContact.address}</span>
                  </div>
                  <div className="flex gap-3"><Phone size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <div className="flex flex-wrap items-center gap-1">
                      <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hcmContact: {...data.hcmContact, representative: e.currentTarget.innerText}})}><strong>{data.hcmContact.representative}</strong></span>
                      <span> - </span>
                      <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hcmContact: {...data.hcmContact, phone: e.currentTarget.innerText}})}>{data.hcmContact.phone}</span>
                      {/* Contact icons - non editable but show branding */}
                      <div className="flex items-center gap-1.5 ml-2 no-export">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Icon_of_Zalo.svg/100px-Icon_of_Zalo.svg.png" className="w-3.5 h-3.5" />
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Viber_logo.svg/2560px-Viber_logo.svg.png" className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3"><Mail size={14} className="shrink-0 text-red-400 mt-0.5" /> 
                    <span contentEditable suppressContentEditableWarning onBlur={(e) => setData({...data, hcmContact: {...data.hcmContact, email: e.currentTarget.innerText}})}>{data.hcmContact.email}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-center gap-12 mt-10 pt-6 border-t border-slate-100 text-[11px] text-slate-400 font-bold uppercase tracking-widest">
              <span className="flex items-center gap-2">
                <Globe size={14} className="text-red-600" /> <span contentEditable onBlur={e => setData({...data, website: e.currentTarget.innerText})}>{data.website}</span>
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck size={14} className="text-red-600" /> MST: <span contentEditable onBlur={e => setData({...data, taxCode: e.currentTarget.innerText})}>{data.taxCode}</span>
              </span>
            </div>
          </footer>
        </div>

        <div className="no-print mt-10 mb-20 text-[11px] font-bold text-slate-400 uppercase tracking-widest bg-white py-3 px-8 rounded-full shadow-lg border border-slate-100 flex gap-10">
          <span>Click vào chữ để sửa trực tiếp</span>
          <span>Dùng phím Enter để xuống dòng</span>
          <span>Sử dụng tổ hợp CTRL + B để in đậm</span>
        </div>
      </main>
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
}
