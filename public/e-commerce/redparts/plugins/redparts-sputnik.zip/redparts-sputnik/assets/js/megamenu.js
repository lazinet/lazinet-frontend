( function( $ ) {
	'use strict';

	/* global redPartsSputnikVars, wpNavMenu */

	$( function() {
		$( '#redparts-megamenu-add-column' ).on( 'click', function() {
			const spinner = $( this ).parents( '.button-controls' ).find( '.spinner' );

			// Show the ajax spinner
			spinner.addClass( 'is-active' );

			wpNavMenu.addItemToMenu( {
				'-1': {
					'menu-item-type': 'custom',
					'menu-item-url': '#',
					'menu-item-title': redPartsSputnikVars.column,
					'menu-item-redparts-type': 'redparts_megamenu_column',
				},
			}, wpNavMenu.addMenuItemToBottom, function() {
				spinner.removeClass( 'is-active' );
			} );
		} );
	} );
}( jQuery ) );
