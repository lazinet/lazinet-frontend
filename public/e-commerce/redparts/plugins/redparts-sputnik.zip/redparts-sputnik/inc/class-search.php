<?php
/**
 * RedParts sputnik search.
 *
 * @package RedParts\Sputnik
 * @since 1.1.0
 * @noinspection SqlResolve
 */

namespace RedParts\Sputnik;

use WP_Query;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Search' ) ) {
	/**
	 * Class Search.
	 *
	 * @package RedParts\Sputnik
	 */
	class Search extends Singleton {
		/**
		 * Initialization.
		 */
		public function init() {
			add_action( 'after_setup_theme', array( $this, 'deferred_init' ) );
		}

		/**
		 * Deferred initialization.
		 */
		public function deferred_init() {
			if ( ! class_exists( 'WooCommerce' ) ) {
				return;
			}

			if ( ! is_admin() ) {
				add_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
				add_action( 'get_search_query', array( $this, 'get_search_query' ) );
			}

			add_action( 'wp_ajax_redparts_sputnik_search_suggestions', array( $this, 'ajax_search_suggestions' ) );
			add_action( 'wp_ajax_nopriv_redparts_sputnik_search_suggestions', array( $this, 'ajax_search_suggestions' ) );
		}

		/**
		 * Modifies search query.
		 *
		 * @param WP_Query $query Query object.
		 */
		public function pre_get_posts( WP_Query $query ) {
			global $wpdb;
			global $redparts_sputnik_search_query;

			if ( $query->is_search && 'product' === $query->get( 'post_type' ) ) {
				$search_query = trim( (string) $query->get( 's' ) );
				$product_ids  = wp_cache_get( 'redparts_sputnik_search_' . $search_query );

				if ( false === $product_ids ) {
					$product_ids = array();

					if ( 'yes' === Settings::instance()->get( 'search_by_sku' ) ) {
						// phpcs:disable WordPress.DB.DirectDatabaseQuery
						$product_ids = array_merge(
							$product_ids,
							$wpdb->get_col(
								$wpdb->prepare(
									"
									SELECT IF(p.post_parent = 0, pm.post_id, p.post_parent)
									FROM $wpdb->postmeta AS pm
									LEFT JOIN $wpdb->posts AS p ON pm.post_id = p.ID
									WHERE meta_key='_sku' AND meta_value = %s
									",
									$search_query
								)
							)
						);
						// phpcs:enable
					}

					$attributes = (array) Settings::instance()->get( 'search_by_attributes' );
					$attributes = array_map( 'wc_attribute_taxonomy_name', $attributes );

					if ( ! empty( $attributes ) ) {
						$placeholders = implode( ', ', array_fill( 0, count( $attributes ), '%s' ) );
						$arguments    = array_merge( $attributes, array( $search_query ) );

						// phpcs:disable WordPress.DB.DirectDatabaseQuery
						// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$product_ids = array_merge(
							$product_ids,
							$wpdb->get_col(
								$wpdb->prepare(
									"
									SELECT tr.object_id
									FROM $wpdb->term_taxonomy AS tt
									LEFT JOIN $wpdb->terms AS t ON tt.term_id = t.term_id
									LEFT JOIN $wpdb->term_relationships AS tr ON tt.term_taxonomy_id = tr.term_taxonomy_id
									WHERE taxonomy IN ($placeholders) AND t.name = %s
									",
									...$arguments
								)
							)
						);
						// phpcs:enable
					}

					wp_cache_set( 'redparts_sputnik_search_' . $search_query, $product_ids );
				}

				if ( empty( $product_ids ) ) {
					return;
				}

				$redparts_sputnik_search_query = $search_query;

				$query->set( 's', '' );
				$query->set( 'post__in', $product_ids );

				// Remove compatibility filter from query.
				$attribute_slug = Vehicles::instance()->get_attribute_slug();

				if ( ! $attribute_slug ) {
					return;
				}

				$tax_query = $query->get( 'tax_query' );

				if ( ! is_array( $tax_query ) ) {
					return;
				}

				foreach ( $tax_query as $i => $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}

					if ( ! isset( $item['taxonomy'] ) || $attribute_slug !== $item['taxonomy'] ) {
						continue;
					}

					unset( $tax_query[ $i ] );
				}

				$query->set( 'tax_query', $tax_query );
			}
		}

		/**
		 * Returns the replaced search query if it was modified using the pre_get_posts hook.
		 *
		 * @param string $default Default search query.
		 *
		 * @return string
		 */
		public function get_search_query( string $default ): string {
			global $redparts_sputnik_search_query;

			if ( ! empty( $redparts_sputnik_search_query ) ) {
				return $redparts_sputnik_search_query;
			}

			return $default;
		}

		/**
		 * Output search suggestions.
		 */
		public function ajax_search_suggestions() {
			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['nonce'] ) ), 'redparts_sputnik_search_suggestions' )
			) {
				wp_send_json_error();
				return;
			}

			if ( ! isset( $_POST['id'] ) || ! isset( $_POST['s'] ) ) {
				wp_send_json_error();
				return;
			}

			$form_id = sanitize_text_field( wp_unslash( $_POST['id'] ) );
			$s       = sanitize_text_field( wp_unslash( $_POST['s'] ) );

			$query_args = array(
				's'              => $s,
				'sentence'       => false,
				'post_type'      => 'product',
				'posts_per_page' => 20,
			);

			if ( ! empty( $_POST['taxonomy'] ) && ! empty( $_POST['taxonomy_value'] ) ) {
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				$query_args['tax_query'] = array(
					'relation' => 'AND',
					array(
						'taxonomy' => sanitize_key( wp_unslash( $_POST['taxonomy'] ) ),
						'field'    => 'slug',
						'terms'    => sanitize_key( wp_unslash( $_POST['taxonomy_value'] ) ),
					),
				);
			}

			$query = new WP_Query( $query_args );

			foreach ( $query->get_posts() as $product ) {
				$query->setup_postdata( $product );
				?>
				<a
					href="<?php echo esc_url( get_the_permalink( $product ) ); ?>"
					class="th-suggestions__item th-suggestions__item--product th-suggestions__product"
					tabindex="-1"
					role="option"
					id="<?php echo esc_attr( $form_id . '-suggestions-option-product-' . $product->ID ); ?>"
					data-s="<?php echo esc_attr( esc_html( get_the_title( $product ) ) ); ?>"
				>
					<div class="th-suggestions__product-image">
						<?php echo wp_kses( woocommerce_get_product_thumbnail( array( 44, 44 ) ), 'redparts_sputnik_image' ); ?>
					</div>
					<div class="th-suggestions__product-info">
						<div class="th-suggestions__product-name">
							<?php
							$product_name = preg_replace(
								'/' . preg_quote( $s, '/' ) . '/i',
								'<strong>$0</strong>',
								esc_html( get_the_title( $product ) )
							);

							echo wp_kses(
								$product_name,
								array(
									'strong' => array(),
								)
							);
							?>
						</div>
						<div class="th-suggestions__product-price th-price">
							<?php woocommerce_template_loop_price(); ?>
						</div>
					</div>
				</a>
				<?php
			}
			$query->reset_postdata();

			if ( $query->found_posts > $query->post_count ) {
				?>
				<a
					href=""
					class="th-suggestions__item th-suggestions__item--all-results"
					tabindex="-1"
					role="option"
					id="<?php echo esc_attr( $form_id . '-suggestions-option-all-results' ); ?>"
					data-s="<?php echo esc_attr( $s ); ?>"
				>
					<?php echo esc_html__( 'See all results', 'redparts_sputnik' ); ?>
				</a>
				<?php
			}

			wp_die();
		}
	}
}
